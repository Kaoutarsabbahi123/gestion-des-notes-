#include <stdio.h>
#include <stdlib.h>
#include<string.h>
typedef struct {
	int num ;
	char ville[20];
}Adresse;//structure Adresse .

typedef struct{
    int jour,mois,annee;
}date;// structure date.

typedef struct {
    char Nom[50];
    char Prenom[50];
	int CNE;
	Adresse adr;
    date dat;
}Etudiant; //structure imbrique (Etudiant)
//Prototype des fonctions.
Etudiant *saisie(int taille);
void Afficher(Etudiant *LEtd ,int taille );
void AfficheParCNE(Etudiant *LEtd ,int taille,int cne );
void echange_Etd(int i ,int j ,Etudiant *LEtd );
void supprimerParCNE(Etudiant *LEtd,int cne,int *taille);
void triparnom(Etudiant *LEtd,int taille);
void triparcne(Etudiant *LEtd,int taille);
Etudiant *chercherdichparnom(Etudiant *LEtd,int taille);
Etudiant *chercherdichparcne(Etudiant *LEtd,int taille);
void ajouter(Etudiant *LEtd,int *taille);
void enregistrer(Etudiant *LEtd,int taille ,char *fichier);
void modifier(Etudiant *LEtd,int taille);

//_____fonction menu______
 	int menu(){
	int choix;
	printf("\n\n___________MENU_________\n\n");
	printf("1-afficher les information :\n");
	printf("2-afficher l'etudiant par cne :\n");
	printf("3-supprimer un etudiant par CNE :\n");
    printf("4-trier la liste par nom :\n");
    printf("5-trier la liste par cne :\n");
    printf("6-recherche dichotomique par cne :\n");
    printf("7-recherche dichotomique par nom:\n");
    printf("8-ajouter des �tudiants :\n");
    printf("9-modifier les informations d'un etudiant :\n");
    printf("0-quitter le programme");
	do{
	printf("\n\n\n\n_________entrez un choix________\n\n");
	scanf("%d",&choix);
	if(choix<0 || choix >9)
	   printf("le choix n'existe pas");
	}while(choix<0 || choix >9);
return choix;
}
int main()
{
   char * fichier = (char *)malloc(100* sizeof(char)); // reservation de memoire
   int  taille,cne;
   int choix_utilisateur;
   Etudiant *LEtd,*etud_cherche,*cherche;
     	printf("\n-Entrez la taille de la liste des etudiants : \t" ) ;
	    scanf( "%d" , &taille) ;
     	LEtd=saisie(taille);
     	enregistrer(LEtd,taille,fichier);
     	do{
		 choix_utilisateur=menu();
     	switch(choix_utilisateur)
      	{
     		case 1 : Afficher(LEtd,taille);
     		         break;
     		case 2 : {	printf("entrer le cne de l'etudiant a rechercher :");
     	                scanf("%d",&cne);
		                AfficheParCNE(LEtd,taille,cne);
     		           break;}
     	    case 3 :{  	printf("entrer le cne de l'etudiant a supprimer :");
     	                scanf("%d",&cne);
			            supprimerParCNE(LEtd,cne,&taille);
     	             break;}
     		case 4 :{  triparnom(LEtd,taille);
			         Afficher(LEtd,taille);
					 break;
				}
			case 5 : {triparcne(LEtd,taille);
			          Afficher(LEtd,taille);
			        	break;
			}
            case 6 :{etud_cherche=chercherdichparcne(LEtd,taille);
                     printf("\n\nNom :%s\n",etud_cherche->Nom);
                     printf("prenom :%s\n",etud_cherche->Prenom);
                     printf("CNE :%d\n",etud_cherche->CNE);
                     printf("Adresse -->num :%d\n",etud_cherche->adr.num);
                     printf("Adresse -->VIlle :%s\n",etud_cherche->adr.ville);
                     printf("date de naissance-->jour :%d\n",etud_cherche->dat.jour);
                     printf("date de naissance-->mois :%d\n",etud_cherche->dat.mois);
                     printf("date de naissance-->annee :%d\n",etud_cherche->dat.annee);
			         break;}
			case 7 : { cherche=chercherdichparnom(LEtd,taille);
			         printf("\n\nNom :%s\n",cherche->Nom);
                     printf("prenom :%s\n",cherche->Prenom);
                     printf("CNE :%d\n",cherche->CNE);
                     printf("Adresse -->num :%d\n",cherche->adr.num);
                     printf("Adresse -->VIlle :%s\n",cherche->adr.ville);
                     printf("date de naissance-->jour :%d\n",cherche->dat.jour);
                     printf("date de naissance-->mois :%d\n",cherche->dat.mois);
                     printf("date de naissance-->annee :%d\n",cherche->dat.annee);
				break;
			}
			case 8 : ajouter(LEtd,&taille);
			        break;
			case 9 : modifier(LEtd,taille);
			         break;
      	}
		}while(choix_utilisateur!=0);
		free(LEtd);
		LEtd=0;

			return 0;
}

//_____Fonction saisie______
 Etudiant * saisie(int taille){
     Etudiant *LEtd=(Etudiant*)calloc(taille,sizeof(Etudiant));// reservation de memoire de tableau LEtd
     int i;
     for(i=0;i<taille;i++){
       // la saisie des informations pour chaque etudiant
         fflush(stdin);
         printf("\n entrer les informations d'etudiant num %d :\n",i+1);
         printf("NOM:");
         gets(LEtd[i].Nom);
         printf("PRENOM :");
         gets(LEtd[i].Prenom);
         printf("CNE :");
         scanf("%d",&LEtd[i].CNE);
         printf("Adresse -->num :");
         scanf("%d",&LEtd[i].adr.num);
         printf("Adresse -->VILLE :");
         fflush(stdin);gets(LEtd[i].adr.ville);
         printf("date de naissance-->jour :");
         scanf("%d",&LEtd[i].dat.jour);
         printf("date de naissance-->mois :");
         scanf("%d",&LEtd[i].dat.mois);
         printf("date de naissance-->annee:");
         scanf("%d",&LEtd[i].dat.annee);
     }
    return LEtd;
 }

//______ Fonction Affichage______
void Afficher(Etudiant *LEtd,int taille){
	int i;
	printf("\n\n\n_____la liste des etudiants_____\n\n");
 	for(i=0;i<taille;i++){
 		printf("\n\nNom :%s\n",LEtd[i].Nom);
 		printf("prenom :%s\n",LEtd[i].Prenom);
        printf("CNE :%d\n",LEtd[i].CNE);
        printf("Adresse -->num :%d\n",LEtd[i].adr.num);
        printf("Adresse -->VIlle :%s\n",LEtd[i].adr.ville);
        printf("date de naissance-->jour :%d\n",LEtd[i].dat.jour);
        printf("date de naissance-->mois :%d\n",LEtd[i].dat.mois);
        printf("date de naissance-->annee :%d\n",LEtd[i].dat.annee);
	 }
}


//_____fonction Afficher par CNE_____
void AfficheParCNE(Etudiant*LEtd,int taille,int cne){
 	int i;
 	for(i=0;i<taille;i++)
 	{
 		if(LEtd[i].CNE==cne)
 		{
 		printf("\n\nNom :%s\n",LEtd[i].Nom);
 		printf("prenom :%s\n",LEtd[i].Prenom);
        printf("CNE :%d\n",LEtd[i].CNE);
        printf("Adresse -->num :%d\n",LEtd[i].adr.num);
        printf("Adresse -->VIlle :%s\n",LEtd[i].adr.ville);
        printf("date de naissance-->jour :%d\n",LEtd[i].dat.jour);
        printf("date de naissance-->mois :%d\n",LEtd[i].dat.mois);
        printf("date de naissance-->annee :%d\n",LEtd[i].dat.annee);
		 }
		else printf("on ne trouve pas ");
	 }
 }
 //_____fonction Echange_______
void echange_Etd(int i,int j,Etudiant *LEtd){
   	    Etudiant tmp;
   	      tmp=*(LEtd+i);
   	      *(LEtd+i)=*(LEtd+j);
   	      *(LEtd+j)=tmp;
   	  }
//______ fonction de suppression_______
void supprimerParCNE(Etudiant *LEtd,int cne,int *taille)
{
	int i,j;
	for(i=0;i<*taille;i++)
     	{
     		if(LEtd[i].CNE==cne)
     		{
     			for(j=i;j<*taille;j++)
     			{
     				*(LEtd+j)=*(LEtd+j+1);
				 }
				 break;
			 }
		 }
		 (*taille)--;
        Afficher(LEtd,*taille);
}
//______fonction de tri par Nom _______
void triparnom(Etudiant *LEtd,int taille)
{
	int i,j,index;
	for(i=0;i<taille-1;i++)
	{
		index=i;
		for(j=i+1;j<taille;j++)
		{
			if(strcmp(LEtd[j].Nom,LEtd[index].Nom)<0)//comparaison caract�re par caract�re
			  index=j;
		}
		if(index!=i)
		echange_Etd(i,index,LEtd);
	}
}
//______fonction de tri par CNE_______
 void triparcne(Etudiant *LEtd,int taille)
 {
 	int i,j;
	for(i=0;i<taille-1;i++)
	{
		for(j=i+1;j<taille;j++)
		{
			if(LEtd[i].CNE>LEtd[j].CNE)
			 echange_Etd(i,j,LEtd);
		}
 }}
 //_______Recherche dichotomique par cne________
Etudiant *chercherdichparcne(Etudiant *LEtd,int taille)
{
    int debut=0,fin=taille-1,milieu;
	int trouve=0,cne;
	printf("entrer le cne d'etudiant a chercher :");
	scanf("%d",&cne);
	triparcne(LEtd,taille);
	while(!trouve && fin >=debut)
	{
	   milieu=(debut+fin)/2;
	   if(cne<LEtd[milieu].CNE)
	     fin=milieu-1;
		else if(cne>LEtd[milieu].CNE)
		    debut=milieu+1;
		else trouve=1;
	}
	if(!trouve)
	   printf("Desole, on ne trouve pas l'etudiant");
	   else return (LEtd+milieu);
}
//__________REcherche dichotomique par nom________
Etudiant *chercherdichparnom(Etudiant *LEtd,int taille)
{
	 char cher[20];
	 int debut=0,fin=taille-1,l;
	 int milieu,trouve=0,c;
	 printf("entrer le nom a chercher :");
	 fflush(stdin);
	 gets(cher);
	 l=strlen(cher);
	 triparnom(LEtd,taille);
	while(!trouve && fin>=debut)
	{
	   milieu=(fin+debut)/2;
	   c=strncmp(cher,LEtd[milieu].Nom,l);// la comparaison se fera au maximum sur les length premiers caract�res
		if(c<0)
		 fin=milieu-1;
		 else if(c>0)
		 debut=milieu+1;
		 else trouve=1;
	}
	if(!trouve)
	   printf("on trouve pas l'etudiant");
	else return (LEtd+milieu);
}
//_____fonction ajouter________
void ajouter(Etudiant *LEtd, int *taille)
{
     char * fichier = (char *)malloc(100* sizeof(char));
    int n,i;
    printf("entrer le nombre d'etudiant a ajouter :");
    scanf("%d",&n);
    *taille=*taille+n;
    LEtd=(Etudiant*)realloc(LEtd,(*taille)*sizeof(Etudiant));
    for(i=*taille-n;i<*taille;i++)
    {
        fflush(stdin);
         printf("\n entrer les informations d'etudiant num %d :\n",i+1);
         printf("NOM:");
         gets(LEtd[i].Nom);
         printf("PRENOM :");
         gets(LEtd[i].Prenom);
         printf("CNE :");
         scanf("%d",&LEtd[i].CNE);
         printf("Adresse -->num :");
         scanf("%d",&LEtd[i].adr.num);
         printf("Adresse -->VILLE :");
          fflush(stdin);gets(LEtd[i].adr.ville);
         printf("date de naissance-->jour :");
         scanf("%d",&LEtd[i].dat.jour);
         printf("date de naissance-->mois :");
         scanf("%d",&LEtd[i].dat.mois);
         printf("date de naissance-->annee:");
         scanf("%d",&LEtd[i].dat.annee);
    }
    enregistrer(LEtd,taille,fichier);
}

//_________fonction enregistrement dans un fichier _______
void enregistrer(Etudiant *LEtd,int taille ,char *fichier){
    int i;
    FILE * liste = fopen("fichier.txt", "w");
    for(i=0;i<taille;i++){
        fprintf(liste,"\n\n Nom:%s\n",LEtd[i].Nom);
        fprintf(liste,"Prenom :%s\n",LEtd[i].Prenom);
        fprintf(liste,"CNE :%d\n",LEtd[i].CNE);
        fprintf(liste,"adresse-->num :%d\n",LEtd[i].adr.num);
        fprintf(liste,"adresse-->ville :%s\n",LEtd[i].adr.ville);
        fprintf(liste,"jour :%d\n",LEtd[i].dat.jour);
        fprintf(liste,"mois :%d\n",LEtd[i].dat.mois);
        fprintf(liste,"annee :%d\n",LEtd[i].dat.annee);
    }
}
//______fonction modifier_________
void modifier(Etudiant *LEtd,int taille){
    int cne ,k,i;
    char * fichier = (char *)malloc(100* sizeof(char));
    printf("entrer le cne d'etudiant que vous voulez modifier :");
     scanf("%d",&cne);
    for(i=0;i<taille;i++)
    {
        if(LEtd[i].CNE==cne)
            k=i;
    }
    fflush(stdin);
         printf("NOM:");
         gets(LEtd[k].Nom);
         printf("PRENOM :");
         gets(LEtd[k].Prenom);
         printf("CNE :");
         scanf("%d",&LEtd[k].CNE);
         printf("Adresse -->num :");
         scanf("%d",&LEtd[k].adr.num);
         printf("Adresse -->VILLE :");
         fflush(stdin);gets(LEtd[k].adr.ville);
         printf("date de naissance-->jour :");
         scanf("%d",&LEtd[k].dat.jour);
         printf("date de naissance-->mois :");
         scanf("%d",&LEtd[k].dat.mois);
         printf("date de naissance-->annee:");
         scanf("%d",&LEtd[k].dat.annee);
         enregistrer(LEtd,taille,fichier);
}
